fig07x010<-function(){
mass<-c(5.9,32.0,40.0,51.5,70.0,100.0,78.0,80.0,85.0,85.0,
110.0,115.0,125.0,130.0,120.0,120.0,130.0,135.0,110.0,130.0,
150.0,145.0,150.0,170.0,225.0,145.0,188.0,180.0,197.0,218.0,
300.0,260.0,265.0,250.0,250.0,300.0,320.0,514.0,556.0,840.0,
685.0,700.0,700.0,690.0,900.0,650.0,820.0,850.0,900.0,1015.0,
820.0,1100.0,1000.0,1100.0,1000.0,1000.0)
#
graphics.off()
windows(width=4.5,height=4.5,pointsize=12)
par(fin=c(4.45,4.45),pin=c(4.45,4.45),
mai=c(0.85,0.85,0.25,0.25),xaxs="r",bty="n")
#
# Variable width histogram
#
brks<-c(0,100,200,300,600,900,1200)
#
hist(mass,breaks=brks,freq=FALSE,main=NULL,
xlab="Mass (g)",xlim=c(0,1400),xaxt="n",
ylab="Relative Frequency",ylim=c(0,0.004))
axis(1,at=(0:7)*200,labels=c("0","","400","","800","","1200",""))
#
# Plot a beta density
#
curve(dbeta(x/1200,0.52,1.11)/1200,from=0,to=1400,add=TRUE,lwd=1.5)
#
dev.copy2eps(file="fig07x010.eps")
dev.copy2pdf(file="fig07x010.pdf")
}

