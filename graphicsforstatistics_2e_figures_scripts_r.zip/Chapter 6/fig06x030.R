fig06x030<-function(){
mass<-c(5.9,32.0,40.0,51.5,70.0,100.0,78.0,80.0,85.0,85.0,
110.0,115.0,125.0,130.0,120.0,120.0,130.0,135.0,110.0,130.0,
150.0,145.0,150.0,170.0,225.0,145.0,188.0,180.0,197.0,218.0,
300.0,260.0,265.0,250.0,250.0,300.0,320.0,514.0,556.0,840.0,
685.0,700.0,700.0,690.0,900.0,650.0,820.0,850.0,900.0,1015.0,
820.0,1100.0,1000.0,1100.0,1000.0,1000.0)
#
graphics.off()
windows(width=4.5,height=4.5,pointsize=12)
par(fin=c(4.45,4.45),pin=c(4.45,4.45),
mai=c(0.85,0.85,0.25,0.25),xaxs="r",bty="n")
#
brks<-(0:12)*100
hist_mass<-hist(mass,breaks=brks,freq=FALSE,
main=NULL,xlab="Mass (g)",xlim=c(0,1200),xaxt="n",
ylab="Relative Frequency",ylim=c(0,0.004))
axis(1,at=(0:6)*200,
labels=c("0","200","400","600","800","1000","1200"))
#
# Smooth spline density estimate
#
lines(smooth.spline(c(0,hist_mass$mids),
c(0,hist_mass$density),spar=0.15),lty=1,lwd=1.5)
lines(smooth.spline(c(0,hist_mass$mids),
c(0,hist_mass$density),spar=0.5),lty=2,lwd=1.5)
#
legend(475,0.003,legend=c("Smoothing = 0.15",
"Smoothing = 0.50"),
lty=c(1,2),lwd=c(1.5,1.5))
#
dev.copy2eps(file="fig06x030.eps")
dev.copy2pdf(file="fig06x030.pdf")
}

